package com.example.android.coinwatcher.components

import android.view.View
import androidx.recyclerview.widget.RecyclerView

class MyViewHolder(val view: View):RecyclerView.ViewHolder(view)